package farmerWorkers;

public class WordRecord {
	String word;
	int frequency;
}
